import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  // Create a parent location (UBI)
  const parentLocation = await prisma.location.upsert({
    where: { id: 'ubi-123' },
    update: {},
    create: {
      id: 'ubi-123',
      name: 'Test Parent Location',
      ubi: 'TESTUBI123',
      licenseNumber: null,
      licenseType: 'licensee',
      enabledModules: ['cultivation', 'inventory', 'pos'],
    },
  });

  // Hash password
  const passwordHash = await bcrypt.hash('TestPassword123!', 10);

  // Create a test user
  const user = await prisma.user.upsert({
    where: { email: 'testuser@example.com' },
    update: {},
    create: {
      id: 'user-123',
      name: 'Test User',
      email: 'testuser@example.com',
      passwordHash,
      role: 'licensee_admin',
      parentLocationId: parentLocation.id,
      isActive: true,
    },
  });

  console.log('Seed data created:', { parentLocation, user });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });