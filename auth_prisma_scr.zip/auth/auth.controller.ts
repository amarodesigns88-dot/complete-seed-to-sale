import { Controller, Post, Body, Get } from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Get('test')
  test() {
    return { message: 'Auth controller is working' };
  }

  @Post('login')
  async login(@Body() body: { email: string; password: string; ubi?: string }) {
    const user = await this.authService.validateUser(body.email, body.password, body.ubi);
    return this.authService.login(user);
  }
}